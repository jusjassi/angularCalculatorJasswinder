/* jasmine specs for widgets go here */
