/* http://docs.angularjs.org/#!angular.service */

