/* http://docs.angularjs.org/#!angular.widget */
