/* http://docs.angularjs.org/#!angular.filter */
