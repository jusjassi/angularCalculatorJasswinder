Running Scenario Tests
----------------------

1. install node.js: http://nodejs.org/
2. install NPM: http://github.com/isaacs/npm
3. install express: npm install express
4. server.sh